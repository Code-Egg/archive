<?php

include __DIR__ . '/autoindex_include.php';

/* Non-JS version, server side sort*/
$page = new \LiteSpeedAutoIndex\Index();
$page->printPage();

