<?php

define ('LEGAL', 1);
define ('TITLE', 'Compile PHP with LSAPI');
define ('OPTION_VERSION', 5);

define ('BUILD_DIR', $_SERVER['LS_SERVER_ROOT'] . 'phpbuild');
define ('LAST_CONF', BUILD_DIR . '/savedconfig.'); // actual file will include . php base version.

define ('DEFAULT_INSTALL_DIR', $_SERVER['LS_SERVER_ROOT'].'lsphp'); // actual dir will include . php base version.

$PHP_VER = [
	'8' => [
		'8.3.6',
		'8.2.18',
		'8.1.28',
		'8.0.30'],
	'7' => [
		'7.4.32',
		'7.3.31',
		'7.2.34',
		'7.1.33',
		'7.0.33'],
	'5' => ['5.6.40']
];

define ('LSAPI_VERSION', '8.1');
define ('SUHOSIN_VERSION', '0.9.38'); // www.suhosin.org
define ('MEMCACHE_VERSION', '2.2.7');	// http://pecl.php.net/package/memcache for php5
define ('MEMCACHE7_VERSION', '4.0.5.2');	// http://pecl.php.net/package/memcache for php7.0-7.4
define ('MEMCACHE8_VERSION', '8.2');	// http://pecl.php.net/package/memcache for php8
define ('MEMCACHED_VERSION', '2.2.0'); // http://pecl.php.net/package/memcached
define ('MEMCACHED7_VERSION', '3.2.0'); // http://pecl.php.net/package/memcached for php7 only

$DEFAULT_PHP_PARAMS = [
	'8' => '--with-mysqli --with-zlib --enable-gd --enable-shmop --enable-sockets --enable-sysvsem --enable-sysvshm --enable-mbstring --with-iconv --with-pdo-mysql --enable-ftp --with-zip --with-curl --enable-soap --enable-xml --with-openssl --enable-bcmath',
	'7' => '--with-mysqli --with-zlib --with-gd --enable-shmop --enable-sockets --enable-sysvsem --enable-sysvshm --enable-mbstring --with-iconv --with-mcrypt --with-pdo-mysql --enable-ftp --enable-zip --with-curl --enable-soap --enable-xml --enable-json  --with-openssl --enable-bcmath',
	'5' => '--with-mysqli --with-zlib --with-gd --enable-shmop --enable-sockets --enable-sysvsem --enable-sysvshm --enable-mbstring --with-iconv --with-mysql --with-mcrypt --with-pdo --with-pdo-mysql --enable-ftp --enable-zip --with-curl --enable-soap --enable-xml --enable-json  --with-openssl --enable-bcmath',
	];


include_once( 'buildfunc.inc.php' );
