<?php
require_once('../includes/auth.php');

$stats = new STATS();
$stats->parse_all();
$blocked_count = count($stats->blocked_ip);

$help_key = 'antiddos_blocked_ip';
$dhelp_item = DATTR_HELP::GetInstance()->GetItem($help_key);
$help = '&nbsp;&nbsp;&nbsp;&nbsp' . $dhelp_item->render($help_key);

echo GUI::header();

?>
<table class="xtbl" width="100%" border="0" cellpadding="4" cellspacing="1">
<tr height="15"><td class="xtbl_title">Current Blocked IP List (Total <?php echo $blocked_count . ')' . $help; ?> </tr>

<tr class="xtbl_value"><td>

<?php
	echo join(', ', $stats->blocked_ip);
?>			

</td></tr>
</table>

<?php

echo GUI::footer();
