<?php

include __DIR__ . '/autoindex_include.php';

/* With JS sort, this is new default */
$page = new \LiteSpeedAutoIndex\IndexWithJS();
$page->printPage();


