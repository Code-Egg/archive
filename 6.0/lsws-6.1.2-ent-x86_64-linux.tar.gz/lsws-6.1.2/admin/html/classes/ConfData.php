<?php

class CVal
{
	private $_v = null; //value
	private $_e = null; //err
	public function __construct($v, $e=null)
	{
		$this->_v = $v;
		$this->_e = $e;
	}
	
	public function GetVal()
	{
		return $this->_v;
	} 
	
	public function SetVal($v)
	{
		$this->_v = $v;
	}
	
	public function HasVal()
	{
		// 0 is valid
		return ($this->_v !== null && $this->_v !== '');
	}
	
	public function GetErr()
	{
		return $this->_e;
	}
	
	public function SetErr($e)
	{
		$this->_e = $e;
	}
	
	public function HasErr()
	{
		return $this->_e != null;
	}
	
}

class ConfData
{
	public $_data;
	public $_path;
	public $_type; //{'serv','admin','vh','tp'}
	public $_id;

	public function __construct($type, $path, $id=null)
	{
		$this->_data = [];
		$this->_type = $type;
		$this->_path = $path;
		$this->_id = $id;
	}

	public function setId($id)
	{
		$this->_id = $id;
	}

}
