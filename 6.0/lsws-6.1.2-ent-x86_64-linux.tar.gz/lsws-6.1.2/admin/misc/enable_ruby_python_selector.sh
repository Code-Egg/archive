#!/bin/bash

RUBY_LSAPI_VER="5\\."
WSGI_LSAPI_VER=2.1

alt_ruby_install()
{
    # $1 = ruby version
    if [ "x$1" != "x" ] && [ -d /opt/alt/ruby$1/bin/ ]; then
        echo "Install ruby-lsapi rack gem for alt-ruby $1"
        yum install -y alt-ruby$1-rubygem-lsapi alt-ruby$1-rubygem-rack
        /opt/alt/ruby$1/bin/gem list ruby-lsapi | grep $RUBY_LSAPI_VER >/dev/null
        if [ $? -ne 0 ]; then
            echo "Alt-ruby $1 misses ruby-lsapi 5.x gem, install latest version."
            /opt/alt/ruby$1/bin/gem install ruby-lsapi
        fi
        echo ""
    fi
}

plesk_ruby_install()
{
    # $1 = ruby version
    # $2 = rack gem version
    if [ "x$1" != "x" ] && [ -d $1 ]; then
        echo "Install ruby-lsapi gem for Plesk ruby $1"
        $1/bin/gem install ruby-lsapi
        if [ "x$2" != "x" ]; then
            $1/bin/gem install rack -v=$2
        else
            $1/bin/gem install rack -v=2.2.4
        fi
        echo ""
    fi
}

alt_python_install()
{
    # $1 = ruby version
    if [ "x$1" != "x" ] && [ -d /opt/alt/python$1/bin/ ]; then
        if [ -d /opt/alt/python$1 ]; then
            echo "Install wsgi-lsapi for python $1"
            yum install -y alt-python$1-wsgi-lsapi
            if [ ! -f /opt/alt/python$1/bin/lswsgi ]; then
                /opt/alt/python$1/bin/python3 configure.py
                yum install devtoolset-7-toolchain
                make 1>/dev/null 2>&1
                cp lswsgi /opt/alt/python$1/bin/
                make clean
            fi
        fi
    fi
}


for VER in '18' '19' '20' '21' '22' '23' '24' '25' '26' '27' '30' '31' '32' '33'
do
    alt_ruby_install $VER
done

rm wsgi-lsapi-$WSGI_LSAPI_VER.tgz
rm -rf wsgi-lsapi-$WSGI_LSAPI_VER

wget http://www.litespeedtech.com/packages/lsapi/wsgi-lsapi-$WSGI_LSAPI_VER.tgz

tar xvfz wsgi-lsapi-$WSGI_LSAPI_VER.tgz
cd wsgi-lsapi-$WSGI_LSAPI_VER

for VER in '27' '33' '34' '35' '36' '37' '38' '39' '310' '311' '312' '313'
do
    alt_python_install $VER
done


if [ -d /opt/plesk/ruby ]; then
    yum install -y gcc gmp-devel
    cd /opt/plesk/ruby
    for VER in '1.9.3' '2.0.0' '2.1.10'
    do
        plesk_ruby_install $VER 1.6.4
    done

    for VER in '2.2.10' '2.3.8' '2.4.10' '2.5.8' '2.6.6' '2.7.1'
    do
        plesk_ruby_install $VER
    done

fi


if [ -d /opt/cpanel/ea-ruby27/ ]; then
    echo "Install ruby-lsapi for ea-ruby27"
    scl enable ea-ruby27 'gem install ruby-lsapi'
    scl enable ea-ruby27 'gem install rack -v=2.2.4'

    if [ ! -f /usr/local/lsws/fcgi-bin/ea-ruby27 ]; then
        cat >/usr/local/lsws/fcgi-bin/ea-ruby27 <<EOF
#!/bin/sh
. /opt/cpanel/ea-ruby27/enable
/opt/cpanel/ea-ruby27/root/usr/bin/ruby \$@

EOF
        chmod a+x /usr/local/lsws/fcgi-bin/ea-ruby27
    fi
    
fi

