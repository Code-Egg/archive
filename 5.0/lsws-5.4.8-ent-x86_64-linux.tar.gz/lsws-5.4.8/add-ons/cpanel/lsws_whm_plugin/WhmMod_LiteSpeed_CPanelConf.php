<?php

/* * ******************************************
 * LiteSpeed Web Server Plugin for WHM
 * @Author: LiteSpeed Technologies, Inc. (https://www.litespeedtech.com)
 * @Copyright: (c) 2018-2019
 * ******************************************* */

namespace LsPanel;

use \Lsc\Wp\Panel\ControlPanel;
use \Lsc\Wp\Panel\CPanel;

class WhmMod_LiteSpeed_CPanelConf
{

    const CPANEL_PLUGIN_DIR =
            '/usr/local/cpanel/base/frontend/paper_lantern/ls_web_cache_manager/';
    const CPANEL_PLUGIN_CONF =
            '/usr/local/cpanel/base/frontend/paper_lantern/ls_web_cache_manager/lswcm.conf';
    const CPANEL_PLUGIN_THEME_DIR =
            '/usr/local/cpanel/base/frontend/paper_lantern/ls_web_cache_manager/landing';

    const FLD_CPANEL_PLUGIN_INSTALLED = 'cpanel_plugin_installed';
    const FLD_CPANEL_PLUGIN_AUTOINSTALL = 'cpanel_plugin_autoinstall';
    const FLD_LSWS_DIR = 'lsws_dir';
    const FLD_VHOST_CACHE_ROOT = 'vhost_cache_root';
    const FLD_USE_CUST_TPL = 'use_cust_tpl';
    const FLD_CUST_TPL_NAME = 'cust_tpl_name';

    /**
     * @var ControlPanel
     */
    private $panelEnv;

    /**
     * @var mixed[]
     */
    private $data;

    /**
     * @var string[]
     */
    private $succ_msgs = array();

    /**
     * @var string[]
     */
    private $err_msgs = array();

    /**
     * @var boolean
     */
    private $save = false;

    public function __construct()
    {
        $this->init();
    }

    /**
     *
     * @return null
     */
    private function init()
    {
        $this->panelEnv = ControlPanel::getClassInstance('\Lsc\Wp\Panel\CPanel');

        $this->data[self::FLD_CPANEL_PLUGIN_AUTOINSTALL] =
                (int)CPanel::isCpanelPluginAutoInstallOn();

        if ( !file_exists(self::CPANEL_PLUGIN_DIR) ) {
            $this->data[self::FLD_CPANEL_PLUGIN_INSTALLED] = false;
            return;
        }

        $this->data[self::FLD_CPANEL_PLUGIN_INSTALLED] = true;

        if ( !file_exists(self::CPANEL_PLUGIN_CONF) ) {
            $this->writeDefaultConf();
            return;
        }

        $contents = file_get_contents(self::CPANEL_PLUGIN_CONF);

        $this->loadSettingLswsHomeDir($contents);
        $this->loadSettingVhCacheRoot($contents);
        $this->loadSettingUseCustTpl($contents);
        $this->loadSettingCustTpl($contents);

        /**
         * Save any detected changes while loading.
         */
        $this->trySaveConf();
    }

    private function writeDefaultConf()
    {
        $this->data[self::FLD_LSWS_DIR] = (defined('LSWS_HOME')) ? LSWS_HOME : '';

        $vhCacheRoot = $this->panelEnv->getVHCacheRoot();

        if ( $vhCacheRoot == ControlPanel::NOT_SET ) {
            $vhCacheRoot = '';
        }

        $this->data[self::FLD_VHOST_CACHE_ROOT] = $vhCacheRoot;
        $this->data[self::FLD_USE_CUST_TPL] = '0';
        $this->data[self::FLD_CUST_TPL_NAME] = '';

        $this->save = true;
        $this->trySaveConf();
    }

    /**
     *
     * @param string  $pattern
     * @param string  $contents
     * @return string
     */
    private function readSetting( $pattern, $contents )
    {
        preg_match($pattern, $contents, $matches);

        if ( isset($matches[1]) ) {
            return $matches[1];
        }
        else {
            return '';
        }
    }

    /**
     * Attempts to create a temporary WhmMod_LiteSpeed_CPanelConf object which
     * should create a cPanel config file if one does not exist or, if it does
     * exist, read the config file setting values and update the file if
     * changes are detected.
     */
    public static function verifyCpanelPluginConfFile()
    {
        if ( file_exists(self::CPANEL_PLUGIN_DIR) ) {
            new self();
        }
    }

    /**
     *
     * @param string  $contents  Contents of lswcm.conf file.
     */
    private function loadSettingLswsHomeDir( $contents )
    {
        $pattern = '/LSWS_HOME_DIR = "(.*)"/';
        $setting = $this->readSetting($pattern, $contents);
        $this->data[self::FLD_LSWS_DIR] = $setting;

        if ( defined('LSWS_HOME')
                && $this->data[self::FLD_LSWS_DIR] != LSWS_HOME) {

            $this->setLswsDir(LSWS_HOME);
        }
    }

    /**
     *
     * @param string  $contents  Contents of lswcm.conf file.
     */
    private function loadSettingVhCacheRoot( $contents )
    {
        $pattern = '/VHOST_CACHE_ROOT = "(.*)"/';
        $setting = $this->readSetting($pattern, $contents);
        $this->data[self::FLD_VHOST_CACHE_ROOT] = $setting;

        $vhCacheRoot = $this->panelEnv->getVHCacheRoot();

        if ( $vhCacheRoot == ControlPanel::NOT_SET ) {
            $vhCacheRoot = '';
        }

        if ( $this->data[self::FLD_VHOST_CACHE_ROOT] != $vhCacheRoot ) {
            $this->setVhCacheRoot($vhCacheRoot);
        }
    }

    /**
     *
     * @param string  $contents  Contents of lswcm.conf file.
     */
    private function loadSettingUseCustTpl( $contents )
    {
        $pattern = '/USE_CUST_TPL = (\d)/';
        $setting = $this->readSetting($pattern, $contents);
        $this->data[self::FLD_USE_CUST_TPL] = (bool)$setting;
    }

    /**
     *
     * @param string  $contents  Contents of lswcm.conf file.
     */
    private function loadSettingCustTpl( $contents )
    {
        $pattern = '/CUST_TPL = "(.*)"/';
        $setting = $this->readSetting($pattern, $contents);
        $this->data[self::FLD_CUST_TPL_NAME] = $setting;
    }

    /**
     *
     * @param string  $field
     * @return mixed
     */
    public function getData( $field = '' )
    {
        if ( !isset($this->data[$field]) ) {
            return null;
        }

        return $this->data[$field];
    }

    /**
     *
     * @param boolean  $clear
     * @return string[]
     */
    public function getSuccMsgs( $clear = false )
    {
        $succMsgs = $this->succ_msgs;

        if ( $clear ) {
            $this->succ_msgs = array();
        }

        return $succMsgs;
    }

    /**
     *
     * @param boolean  $clear
     * @return string[]
     */
    public function getErrMsgs( $clear = false )
    {
        $errMsgs = $this->err_msgs;

        if ( $clear ) {
            $this->err_msgs = array();
        }

        return $errMsgs;
    }

    public function setAutoInstallUse( $autoInstall )
    {
        if ( $autoInstall != $this->data[self::FLD_CPANEL_PLUGIN_AUTOINSTALL] ) {
            $this->data[self::FLD_CPANEL_PLUGIN_AUTOINSTALL] = $autoInstall;
            $this->save = true;
        }

        if ( $autoInstall === 1 ) {
            CPanel::turnOnCpanelPluginAutoInstall();
        }
        else {
            CPanel::turnOffCpanelPluginAutoInstall();
        }

        return true;
    }

    /**
     *
     * @param boolean  $useCustTpl
     * @return boolean
     */
    public function setTplUse( $useCustTpl )
    {
        if ( $useCustTpl != $this->data[self::FLD_USE_CUST_TPL] ) {
            $this->data[self::FLD_USE_CUST_TPL] = $useCustTpl;
            $this->save = true;
        }

        return true;
    }

    public function clearTplName()
    {
        $this->data[self::FLD_CUST_TPL_NAME] = '';
        $this->save = true;
    }

    /**
     *
     * @param string  $newCustTpl
     * @return boolean
     */
    public function setTplName( $newCustTpl )
    {
        if ( $newCustTpl == $this->data[self::FLD_CUST_TPL_NAME] ) {
            return true;
        }

        $themeDir = self::CPANEL_PLUGIN_THEME_DIR;

        if ( $newCustTpl != ''
                && file_exists("{$themeDir}/{$newCustTpl}/index.php") ) {

            $this->data[self::FLD_CUST_TPL_NAME] = $newCustTpl;
            $this->save = true;

            $this->succ_msgs[] = "Custom template {$newCustTpl} set";

            return true;
        }
        else {
            $this->err_msgs[] =
                    "Could not find index.php file for custom template '{$newCustTpl}'";

            return false;
        }
    }

    /**
     *
     * @param string  $newLswsDir
     * @return boolean
     */
    private function setLswsDir( $newLswsDir )
    {
        if ( !is_dir($newLswsDir) ) {
            return false;
        }

        $this->data[self::FLD_LSWS_DIR] = $newLswsDir;
        $this->save = true;

        $this->succ_msgs[] = 'LSWS_HOME_DIR set in cPanel Plugin conf file.';

        return true;
    }

    /**
     *
     * @param string  $newVhCacheRoot
     * @return boolean
     */
    public function setVhCacheRoot( $newVhCacheRoot )
    {
        $this->data[self::FLD_VHOST_CACHE_ROOT] = $newVhCacheRoot;
        $this->save = true;

        $this->succ_msgs[] = 'VHOST_CACHE_ROOT set in cPanel Plugin conf file.';

        return true;
    }

    /**
     *
     * @return null
     */
    public function trySaveConf()
    {
        if ( !$this->save ) {
            return;
        }

        $useCustTpl = (int)$this->data[self::FLD_USE_CUST_TPL];

        $content = <<<EOF
LSWS_HOME_DIR = "{$this->data[self::FLD_LSWS_DIR]}"
VHOST_CACHE_ROOT = "{$this->data[self::FLD_VHOST_CACHE_ROOT]}"
USE_CUST_TPL = {$useCustTpl}
CUST_TPL = "{$this->data[self::FLD_CUST_TPL_NAME]}"

EOF;
        file_put_contents(self::CPANEL_PLUGIN_CONF, $content);

        $this->save = false;
    }

}
