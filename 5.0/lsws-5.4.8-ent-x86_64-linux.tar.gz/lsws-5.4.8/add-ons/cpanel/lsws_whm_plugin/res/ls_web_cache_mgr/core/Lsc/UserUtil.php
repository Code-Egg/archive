<?php

/* * *********************************************
 * LiteSpeed Web Cache Management Plugin for cPanel
 * @Author: LiteSpeed Technologies, Inc. (https://www.litespeedtech.com)
 * @Copyright: (c) 2018-2019
 * *******************************************
 */

namespace LsUserPanel\Lsc;

use \LsUserPanel\Ls_WebCacheMgr_Util;
use \LsUserPanel\Lsc\UserLogger;
use \LsUserPanel\PluginSettings;

class UserUtil
{

    public static function getUserCacheDir()
    {
        $vhCacheRoot =
                PluginSettings::getSetting(PluginSettings::FLD_VHOST_CACHE_ROOT);

        if ( !empty($vhCacheRoot) && $vhCacheRoot[0] != '/' ) {
            $homeDir = Ls_WebCacheMgr_Util::getHomeDir();
            $vhCacheRoot = "{$homeDir}/{$vhCacheRoot}";
        }

        return ($vhCacheRoot == '') ? '' : $vhCacheRoot;
    }

    /**
     * Flushes LiteSpeed Cache for the current user by removing all VH cache
     * files.
     *
     * @param string  $cacheDir  Path to user's VH cache directory.
     * @retun null
     */
    public static function flushVHCacheRoot( $cacheDir )
    {
        $flushed = false;

        $validCacheSubDirs = array(
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'
        );

        if ( !file_exists($cacheDir) ) {
            $msg = sprintf(_('Could Not Find Cache Directory %s'),
                    htmlspecialchars($cacheDir));

            UserLogger::addUiMsg($msg, UserLogger::UI_ERR);
            return;
        }

        foreach ( $validCacheSubDirs as $subDir ) {

            if ( Ls_WebCacheMgr_Util::rrmdir("{$cacheDir}/{$subDir}") ) {
                $flushed = true;
            }
        }

        if ( $flushed ) {
            $msg = _('Cache Files Successfully Flushed');
        }
        else {
            $msg = _('No Cache Files To Flush');
        }

        UserLogger::addUiMsg($msg, UserLogger::UI_SUCC);
    }

    /**
     *
     * @return string
     */
    public static function getUserLSCMDataDir()
    {
        $dataDir = Ls_WebCacheMgr_Util::getHomeDir() . '/lscmData';

        return $dataDir;
    }

    /**
     *
     * @throws UserLSCMException
     */
    public static function createUserLSCMDataDir()
    {
        $dataDir = self::getUserLSCMDataDir();

        if ( !mkdir($dataDir, 0700) ) {
            throw new UserLSCMException('Could not create LSCM user data direcotry.');
        }

        $readmeContent = self::getLscmUserDirReadmeContent();
        file_put_contents("{$dataDir}/readme", $readmeContent);
    }

    /**
     *
     * @return string
     */
    public static function getLscmUserDirReadmeContent()
    {

        $readmeContent = <<<CONTENT
This directory is used to store scan data and other files created by the
LiteSpeed Web Cache Manger plugin for cPanel.

If you are not longer using the LiteSpeed Web Cache Manger plugin for cPanel,
this directory and it's files can be safely removed.
CONTENT;

        return $readmeContent;
    }

}
