<?php

/* * *********************************************
 * LiteSpeed Web Cache Management Plugin for cPanel
 * @Author: LiteSpeed Technologies, Inc. (https://www.litespeedtech.com)
 * @Copyright: (c) 2018-2019
 * *******************************************
 */

use \LsUserPanel\Lsc\Context\UserContext;
use \LsUserPanel\Lsc\Context\UserPanelContextOption;

UserContext::initialize(new UserPanelContextOption('cpanel'));
