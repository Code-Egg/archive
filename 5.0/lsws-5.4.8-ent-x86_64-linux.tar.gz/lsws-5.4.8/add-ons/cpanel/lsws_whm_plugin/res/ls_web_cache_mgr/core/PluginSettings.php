<?php

/* * ******************************************
 * LiteSpeed Web Cache Management Plugin for cPanel
 * @Author: LiteSpeed Technologies, Inc. (https://www.litespeedtech.com)
 * @Copyright: (c) 2018-2019
 * ******************************************* */

namespace LsUserPanel;

use \LsUserPanel\Lsc\UserLSCMException;
use \LsUserPanel\Ls_WebCacheMgr_Util;

class PluginSettings
{

    const FLD_LSWS_HOME_DIR = 'lswsHomeDir';
    const FLD_VHOST_CACHE_ROOT = 'vhostCacheRoot';
    const FLD_USE_CUST_THEME = 'useCustTheme';
    const FLD_CUST_THEME = 'custTheme';

    /**
     * @var null|UserSettings
     */
    private static $instance;

    /**
     * @var string
     */
    private $confFile = 'lswcm.conf';

    /**
     * @var string
     */
    private $lswsHomeDir = '';

    /**
     * @var string
     */
    private $vhCacheRoot = '';

    /**
     * @var boolean
     */
    private $useCustTheme = false;

    /**
     * @var string
     */
    private $custTheme = '';

    private function __construct()
    {
        $this->init();
    }

    private function init()
    {
        if ( file_exists($this->confFile) ) {
            $this->readSettingsFile();
        }
    }

    /**
     *
     * @throws UserLSCMException
     */
    public static function initialize()
    {
        if ( self::$instance != null ) {
            /**
             * Do not allow, already initialized.
             */
            throw new UserLSCMException('PluginSettings cannot be initialized twice.',
                    UserLSCMException::E_PROGRAM);
        }

        self::$instance = new self();
    }

    /**
     *
     * @return UserSettings
     * @throws UserLSCMException
     */
    private static function me()
    {
        if ( self::$instance == null ) {
            /**
             * Do not allow, must initialize first.
             */
            throw new UserLSCMException('Uninitialized PluginSettings.');
        }

        return self::$instance;
    }

    /**
     *
     * @param string  $setting
     * @return mixed
     */
    public static function getSetting( $setting )
    {
        $m = self::me();

        $func = 'get' . ucfirst($setting);

        if ( method_exists($m, $func) ) {
            return $m->{$func}();
        }

        return null;
    }

    /**
     *
     * @return string
     */
    private function getLswsHomeDir()
    {
        return $this->lswsHomeDir;
    }

    /**
     *
     * @return string
     */
    private function getVhostCacheRoot()
    {
        return $this->vhCacheRoot;
    }

    /**
     *
     * @return boolean
     */
    private function getUseCustTheme()
    {
        return $this->useCustTheme;
    }

    /**
     *
     * @return string
     */
    private function getCustTheme()
    {
        return $this->custTheme;
    }

    /**
     *
     * @param string  $pattern
     * @param string  $contents
     * @return string
     */
    private function readSetting( $pattern, $contents )
    {
        preg_match($pattern, $contents, $matches);

        if ( isset($matches[1]) ) {
            return $matches[1];
        }
        else {
            return '';
        }
    }

    /**
     * Reads the contents of the cPanel plugin's conf file and sets any
     * the values for any expected settings found.
     */
    private function readSettingsFile()
    {
        $contents = file_get_contents($this->confFile);

        $pattern = '/LSWS_HOME_DIR = "(.+)"/';
        $lswsHomeDir = $this->readSetting($pattern, $contents);

        if ( !empty($lswsHomeDir) ) {
            $this->lswsHomeDir = $lswsHomeDir;
        }

        $pattern = '/VHOST_CACHE_ROOT = "(.*)"/';
        $vhCacheRoot = $this->readSetting($pattern, $contents);

        if ( !empty($vhCacheRoot) ) {

            if ( $vhCacheRoot[0] == '/' ) {
                $user = Ls_WebCacheMgr_Util::getCurrentCpanelUser();
                $vhCacheRoot = str_replace('/$vh_user', "/{$user}", $vhCacheRoot);
            }

            $this->vhCacheRoot = $vhCacheRoot;
        }

        $pattern = '/USE_CUST_TPL = (\d)/';
        $useCustTheme = $this->readSetting($pattern, $contents);

        if ( !empty($useCustTheme) ) {
            $this->useCustTheme= (bool)$useCustTheme;
        }

        $pattern = '/CUST_TPL = "(.*)"/';
        $custTheme = $this->readSetting($pattern, $contents);

        if ( !empty($custTheme) ) {
            $this->custTheme = $custTheme;
        }
    }

}
