
package Cpanel::API::lsws;

use strict;
use warnings 'all';
use utf8;

# Cpanel Dependencies
use Cpanel         ();
use Cpanel::API    ();
use Cpanel::Locale ();
use Cpanel::Logger ();

use Cpanel::AdminBin::Call();
use Data::Dumper;
use IPC::Run;

# Globals
my $logger;
my $locale;

sub getDocrootData {

    #Prevent potential action-at-a-distance bugs.
    #(cf. documentation for CPAN's Try::Tiny module)
    local $@;

    my ( $args, $result ) = @_;

    my $cmd = $args->get_length_required('cmd');

    my $ret = `$cmd`;

    $result->data(
        {
            docrootData => $ret
        }
    );
}

sub getScanDirs {

    #Prevent potential action-at-a-distance bugs.
    #(cf. documentation for CPAN's Try::Tiny module)
    local $@;

    my ( $args, $result ) = @_;

    my $docroot = $args->get_length_required('docroot');
    my $depth = $args->get_length_required('depth');

    my @cmd = (
        "find",
        "-L",
        $docroot,
        "-maxdepth",
        $depth,
        "-name",
        "wp-admin",
        "-print"
    );

    my $output = '';

    IPC::Run::run \@cmd, \undef, \$output;

    chomp($output);

    $result->data(
        {
            scanData => $output
        }
    );
}

sub retrieveLscwpTranslation
{
    #Prevent potential action-at-a-distance bugs.
    #(cf. documentation for CPAN's Try::Tiny module)
    local $@;

    my ( $args, $result ) = @_;

    my $locale = $args->get_length_required('locale');
    my $pluginVer = $args->get_length_required('pluginVer');

    # Strip invalid chars from input
    $locale =~ s/[^A-Za-z_]//g;
    $pluginVer =~ s/[^0-9.]//g;

    my $ret = Cpanel::AdminBin::Call::call( 'Lsws', 'lswsAdminBin',
      'RETRIEVE_LSCWP_TRANSLATION', $locale, $pluginVer );

    $result->data(
        {
            result => $ret
        }
    );
}

sub removeLscwpTranslationZip
{
    #Prevent potential action-at-a-distance bugs.
    #(cf. documentation for CPAN's Try::Tiny module)
    local $@;

    my ( $args ) = @_;

    my $locale = $args->get_length_required('locale');
    my $pluginVer = $args->get_length_required('pluginVer');

    # Strip invalid chars from input
    $locale =~ s/[^A-Za-z_]//g;
    $pluginVer =~ s/[^0-9.]//g;

    my $ret = Cpanel::AdminBin::Call::call( 'Lsws', 'lswsAdminBin',
      'REMOVE_LSCWP_TRANSLATION_ZIP', $locale, $pluginVer );
}

sub removeNewLscwpFlagFile
{
    #Prevent potential action-at-a-distance bugs.
    #(cf. documentation for CPAN's Try::Tiny module)
    local $@;

    my ( $args, $result ) = @_;

    my $path = $args->get_length_required('path');

    my $ret = Cpanel::AdminBin::Call::call( 'Lsws', 'lswsAdminBin',
            'REMOVE_NEW_LSCWP_FLAG_FILE', $path );

    $result->data(
        {
            result => $ret
        }
    );
}

sub execIssueCmd {

    #Prevent potential action-at-a-distance bugs.
    #(cf. documentation for CPAN's Try::Tiny module)
    local $@;

    my ( $args, $result ) = @_;

    my $username = _getUsername();

    my $cmd = $args->get_length_required('cmd');

    my %ret =
      Cpanel::AdminBin::Call::call( 'Lsws', 'lswsAdminBin', 'EXEC_ISSUE_CMD',
        $username, $cmd );

    my $retVar = %ret{'retVar'};
    my $output = %ret{'output'};

    $result->data(
        {
            retVar => $retVar,
            output => $output,
        }
    );
}

sub _getUsername {
    my $username = $ENV{LOGNAME} || $ENV{USER} || getpwuid($<);

    return $username;
}

1;
