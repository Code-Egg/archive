#!/bin/sh
if [ $# -lt 2 ] ; then 
    echo "miss parameter."
else
    RUNAVCMD=$1
    shift
    for var in "$@"
    do
        $RUNAVCMD $var
    done
fi
